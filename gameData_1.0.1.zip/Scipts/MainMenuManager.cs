using UnityEngine;
using UnityEngine.Networking;
using System.Collections;
using TMPro;
using System.IO;
using Unity.SharpZipLib.Zip;

public class MainMenuManager : MonoBehaviour
{
    public TMP_Text statusText;
    private const string VersionCheckUrl = "https://svenfruiti.github.io/Version_check/version.json";
    private const string DownloadDataUrl = "https://svenfruiti.github.io/Version_check/gameData_1.0.1.zip"; // URL f�r Version 1.0.1
    private const string CurrentVersion = "1.0.0"; // Ersetze dies durch die aktuelle Version deines Spiels

    public float checkInterval = 3600f; // Intervall in Sekunden (z.B. jede Stunde)

    void Start()
    {
        StartCoroutine(CheckVersionPeriodically());
    }

    private IEnumerator CheckVersionPeriodically()
    {
        while (true)
        {
            yield return new WaitForSeconds(checkInterval);
            yield return StartCoroutine(CheckVersionCoroutine());
        }
    }

    private IEnumerator CheckVersionCoroutine()
    {
        using (UnityWebRequest www = UnityWebRequest.Get(VersionCheckUrl))
        {
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                string jsonResponse = www.downloadHandler.text;
                var versionInfo = JsonUtility.FromJson<GameVersionInfo>(jsonResponse); // Verwende die umbenannte Klasse
                string latestVersion = versionInfo.version;

                if (latestVersion != CurrentVersion)
                {
                    statusText.text = "Update verf�gbar. Herunterladen...";
                    yield return StartCoroutine(DownloadGameData(DownloadDataUrl));
                }
                else
                {
                    statusText.text = "Das Spiel ist auf dem neuesten Stand.";
                }
            }
            else
            {
                statusText.text = $"Fehler bei der Versionspr�fung: {www.error}";
            }
        }
    }

    private IEnumerator DownloadGameData(string downloadUrl)
    {
        string zipFilePath = Path.Combine(Application.persistentDataPath, "gameData.zip");

        using (UnityWebRequest www = UnityWebRequest.Get(downloadUrl))
        {
            www.downloadHandler = new DownloadHandlerFile(zipFilePath);
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                statusText.text = "Spieldaten erfolgreich heruntergeladen.";
                // Entpacke die Daten hier
                UnzipFile(zipFilePath, Application.persistentDataPath);
            }
            else
            {
                statusText.text = $"Fehler beim Herunterladen der Spieldaten: {www.error}";
            }
        }
    }

    private void UnzipFile(string zipFilePath, string extractPath)
    {
        if (!Directory.Exists(extractPath))
        {
            Directory.CreateDirectory(extractPath);
        }

        using (FileStream fs = new FileStream(zipFilePath, FileMode.Open, FileAccess.Read))
        using (ZipInputStream zipInputStream = new ZipInputStream(fs))
        {
            ZipEntry entry;
            while ((entry = zipInputStream.GetNextEntry()) != null)
            {
                string fullPath = Path.Combine(extractPath, entry.Name);
                if (entry.IsDirectory)
                {
                    if (!Directory.Exists(fullPath))
                    {
                        Directory.CreateDirectory(fullPath);
                    }
                }
                else
                {
                    using (FileStream fileStream = File.Create(fullPath))
                    {
                        zipInputStream.CopyTo(fileStream);
                    }
                }
            }
        }
    }
}

[System.Serializable]
public class GameVersionInfo // Klasse umbenannt, um Namenskonflikte zu vermeiden
{
    public string version;
}
