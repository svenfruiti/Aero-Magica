using UnityEngine;
using TMPro; // Wichtig f�r TextMeshPro
using System.Collections;
using UnityEngine.Networking;
using PlayFab;
using PlayFab.ClientModels;

public class LoginManager : MonoBehaviour
{
    public TMP_InputField emailInput;
    public TMP_InputField passwordInput;
    public TMP_Text statusText;

    private const string CurrentVersion = "1.0.0";
    private const string VersionCheckUrl = "https://svenfruiti.github.io/Version_check/version.json";

    void Start()
    {
        // Optional: Pr�fen, ob der Benutzer bereits eingeloggt ist, um den Login-Bildschirm zu �berspringen
    }

    public void OnLoginButtonClicked()
    {
        if (string.IsNullOrEmpty(emailInput.text) || string.IsNullOrEmpty(passwordInput.text))
        {
            statusText.text = "Bitte E-Mail und Passwort eingeben.";
            return;
        }

        var request = new LoginWithEmailAddressRequest
        {
            Email = emailInput.text,
            Password = passwordInput.text,
        };
        PlayFabClientAPI.LoginWithEmailAddress(request, OnLoginSuccess, OnLoginFailure);
    }

    public void OnRegisterButtonClicked()
    {
        if (string.IsNullOrEmpty(emailInput.text) || string.IsNullOrEmpty(passwordInput.text))
        {
            statusText.text = "Bitte E-Mail und Passwort eingeben.";
            return;
        }

        var request = new RegisterPlayFabUserRequest
        {
            Email = emailInput.text,
            Password = passwordInput.text,
            RequireBothUsernameAndEmail = false
        };
        PlayFabClientAPI.RegisterPlayFabUser(request, OnRegisterSuccess, OnRegisterFailure);
    }

    private void OnLoginSuccess(LoginResult result)
    {
        statusText.text = "Login erfolgreich!";
        CheckGameVersion();
    }

    private void OnLoginFailure(PlayFabError error)
    {
        statusText.text = $"Login fehlgeschlagen: {error.GenerateErrorReport()}";
    }

    private void OnRegisterSuccess(RegisterPlayFabUserResult result)
    {
        statusText.text = "Registrierung erfolgreich! Sie k�nnen sich nun einloggen.";
    }

    private void OnRegisterFailure(PlayFabError error)
    {
        statusText.text = $"Registrierung fehlgeschlagen: {error.GenerateErrorReport()}";
    }

    private void CheckGameVersion()
    {
        statusText.text = "Pr�fe auf Updates...";
        StartCoroutine(CheckVersionCoroutine());
    }

    private IEnumerator CheckVersionCoroutine()
    {
        using (UnityWebRequest www = UnityWebRequest.Get(VersionCheckUrl))
        {
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                // Parse JSON response
                string jsonResponse = www.downloadHandler.text;
                var versionInfo = JsonUtility.FromJson<VersionInfo>(jsonResponse);
                string latestVersion = versionInfo.version;

                if (latestVersion != CurrentVersion)
                {
                    statusText.text = "Ein Update ist verf�gbar!";
                    // Update-Logik hier
                }
                else
                {
                    statusText.text = "Das Spiel ist auf dem neuesten Stand.";
                    LoadGameData();
                }
            }
            else
            {
                statusText.text = $"Fehler bei der Versionspr�fung: {www.error}";
            }
        }
    }

    private void LoadGameData()
    {
        statusText.text = "Lade Spieldaten...";
        StartGame();
    }

    private void StartGame()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene("MainMenu");
    }
}

[System.Serializable]
public class VersionInfo
{
    public string version;
}
